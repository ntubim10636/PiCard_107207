package com.example.ntub.myapplication;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;


/**
 * A simple {@link Fragment} subclass.
 */
public class SettingFragment extends Fragment {


    SharedPreferences spref;

    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection   conn= connectionDB.CONN();;

    ListView lv;
    String[] myList={"會員資料編輯","移除此帳號","關於"};

    public SettingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("會員專區");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");
        View view=inflater.inflate(R.layout.fragment_setting, container, false);

        lv=view.findViewById(R.id.setList);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_list_item_1, myList){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                // Get the Item from ListView
                View view = super.getView(position, convertView, parent);

                // Initialize a TextView for ListView each Item
                TextView tv = (TextView) view.findViewById(android.R.id.text1);
                tv.setTextSize(20);

                // Set the text color of TextView (ListView Item)
                tv.setTextColor(Color.BLACK);

                // Generate ListView Item using TextView
                return view;
            }
        };

        lv.setAdapter(arrayAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.screen_area,new MemberFragment()).addToBackStack(null);
                    ft.commit();
                }else if(position==1){
                    PreparedStatement preStatement=null ;
                    try {
                        spref = getActivity().getSharedPreferences(KEY,MODE_PRIVATE);
                        preStatement = conn.prepareStatement("Delete from member where member_id=?");
                        preStatement.setString(1,spref.getString("userID",""));
                        int result = preStatement.executeUpdate();

                        spref.edit().clear().commit();

                        Intent intent = new Intent();
                        intent.setClass(getActivity(),LoginActivity.class);
                        startActivity(intent);
                        Toast.makeText(getActivity(),"已刪除帳號\n 請重新註冊", Toast.LENGTH_LONG).show();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }



                }else{
                    android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.screen_area,new AboutFragment()).addToBackStack(null);
                    ft.commit();
                }
            }
        });
        return view;
    }

}
