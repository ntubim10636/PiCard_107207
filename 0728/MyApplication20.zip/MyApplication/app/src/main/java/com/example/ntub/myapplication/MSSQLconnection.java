package com.example.ntub.myapplication;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.StrictMode;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Date;


public class MSSQLconnection {

    private static final String LOG = "DEBUG";

    private static String _server = "140.131.114.241";
    private static String _DB = "107-207";
    private static String _user = "ntubim10636";
    private static String _pass = "10636ntubim";

@SuppressLint("NewApi")
public Connection CONN() {
    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
            .permitAll().build();
    StrictMode.setThreadPolicy(policy);
    Connection conn = null;
    String ConnURL = null;
    try {

        Class.forName("net.sourceforge.jtds.jdbc.Driver");
        ConnURL = "jdbc:jtds:sqlserver://" + _server + ";"
                + "databaseName=" + _DB + ";user=" + _user + ";password="
                + _pass + ";";
        conn = DriverManager.getConnection(ConnURL);
    } catch (SQLException se) {
        Log.e("ERRO", se.getMessage());
    } catch (ClassNotFoundException e) {
        Log.e("ERRO", e.getMessage());
    } catch (Exception e) {
        Log.e("ERRO", e.getMessage());
    }
    return conn;
}

}