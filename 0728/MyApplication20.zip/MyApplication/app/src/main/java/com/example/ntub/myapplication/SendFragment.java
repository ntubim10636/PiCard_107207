package com.example.ntub.myapplication;


import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.UnsupportedEncodingException;

import io.chirp.connect.ChirpConnect;
import io.chirp.connect.interfaces.ConnectEventListener;
import io.chirp.connect.interfaces.ConnectLicenceListener;
import io.chirp.connect.models.ChirpError;
import io.chirp.connect.models.ConnectState;


/**
 * A simple {@link Fragment} subclass.
 */
public class SendFragment extends Fragment {

    private ChirpConnect chirpConnect;

    private static final int RESULT_REQUEST_RECORD_AUDIO = 1;

    TextView status;
    TextView lastChirp;
    TextView versionView;
    EditText username,userphone,usercom;

    Button startStopSdkBtn;
    Button startStopSendingBtn;

    Boolean startStopSdkBtnPressed = false;
    int i=1;

    Activity activity = getActivity();

    public SendFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("傳送名片");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");
        View v=inflater.inflate(R.layout.fragment_send, container, false);

        final View parentLayout = v.findViewById(android.R.id.content);
        status = (TextView) v.findViewById(R.id.stateValue);
        lastChirp = (TextView) v.findViewById(R.id.lastChirp);
        versionView = (TextView) v.findViewById(R.id.versionView);
        startStopSdkBtn = (Button) v.findViewById(R.id.startStopSdkBtn);
        startStopSendingBtn = (Button) v.findViewById(R.id.startStopSengingBtn);

        username = (EditText) v.findViewById(R.id.uname);
        userphone = (EditText) v.findViewById(R.id.uphone);
        usercom = (EditText) v.findViewById(R.id.ucom);

        startStopSendingBtn.setAlpha(.4f);
        startStopSendingBtn.setClickable(false);
        startStopSdkBtn.setAlpha(.4f);
        startStopSdkBtn.setClickable(false);

        Log.v("Connect Version: ", ChirpConnect.getVersion());
        versionView.setText(ChirpConnect.getVersion());

        String APP_KEY = "89e296F325A378B6cFeE3a8dc";
        String APP_SECRET = "5C7CdF6Da498ea2dccAf6fa15eEfB2e46c9395edf09aff401b";

        /**
         * Key and secret initialisation
         */
        chirpConnect = new ChirpConnect(getActivity(), APP_KEY, APP_SECRET);
        chirpConnect.getLicence(new ConnectLicenceListener() {

            @Override
            public void onSuccess(String licence) {
                ChirpError licenceError = chirpConnect.setLicence(licence);
                if (licenceError.getCode() > 0) {
                    Log.e("setLicenceError", licenceError.getMessage());
                    return;
                }
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startStopSdkBtn.setAlpha(1f);
                        startStopSdkBtn.setClickable(true);
                    }
                });
            }

            @Override
            public void onError(ChirpError chirpError) {
                Log.e("getLicenceError", chirpError.getMessage());
            }
        });

        chirpConnect.setListener(new ConnectEventListener() {
            String lasttext="";
            @Override
            public void onSending(byte[] data) {
                /**
                 * onSending is called when a send event begins.
                 * The data argument contains the payload being sent.
                 */
                String hexData = "null";
                if (data != null) {
                    //hexData = bytesToHex(data);
                }
                Log.i("connectdemoapp", "ConnectCallback: onSending: " + hexData);
                String text=new String(data);
                Log.i("TEST", "TEST" + text);
                lasttext += text;
                // lasttext = lasttext + text;
                Log.i("TEST", "TEST lasttext" + lasttext);
                updateLastPayload(lasttext);

            }

            @Override
            public void onSent(byte[] data) {
                /**
                 * onSent is called when a send event has completed.
                 * The data argument contains the payload that was sent.
                 */
                String hexData = "null";
                if (data != null) {
                    //hexData = bytesToHex(data);
                }

                String text=new String(data);
                lasttext =text;

                //lasttext = lasttext + text;
                updateLastPayload(lasttext);
                Log.v("connectdemoapp", "ConnectCallback: onSent: " + hexData);
            }

            @Override
            public void onReceiving() {
                /**
                 * onReceiving is called when a receive event begins.
                 * No data has yet been received.
                 */
                Log.v("connectdemoapp", "ConnectCallback: onReceiving");
            }

            @Override
            public void onReceived(byte[] data) {
                /**
                 * onReceived is called when a receive event has completed.
                 * If the payload was decoded successfully, it is passed in data.
                 * Otherwise, data is null.
                 */
                String hexData = "null";
                if (data != null) {
                    // hexData = bytesToHex(data);
                }
                Log.v("connectdemoapp", "ConnectCallback: onReceived: " + hexData);

                String text=new String(data);
                String sendstr =text;
                lasttext =lasttext+sendstr;
                //lasttext = lasttext + text;
                updateLastPayload(lasttext);
            }

            @Override
            public void onStateChanged(byte oldState, byte newState) {
                /**
                 * onStateChanged is called when the SDK changes state.
                 */
                Log.v("connectdemoapp", "ConnectCallback: onStateChanged " + oldState + " -> " + newState);
                if (newState == 0) {
                    updateStatus("Stopped");
                } else if (newState == 1) {
                    updateStatus("Paused");
                } else if (newState == 2) {
                    updateStatus("Running");
                } else if (newState == 3) {
                    updateStatus("Sending");
                } else if (newState == 4) {
                    updateStatus("Receiving");
                } else {
                    updateStatus(newState + "");
                }

            }

            @Override
            public void onSystemVolumeChanged(int oldVolume, int newVolume) {
                /**
                 * onSystemVolumeChanged is called when the system volume is changed.
                 */
                Snackbar snackbar = Snackbar.make(parentLayout, "System volume has been changed to: " + newVolume, Snackbar.LENGTH_LONG);
                snackbar.setAction("CLOSE", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                })
                        .setActionTextColor(getResources().getColor(android.R.color.holo_red_light ))
                        .show();
                Log.v("connectdemoapp", "System volume has been changed, notify user to increase the volume when sending data");
            }

        });

        startStopSdkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startStopSdkBtnPressed = true;
                if (chirpConnect.getConnectState() == ConnectState.AudioStateStopped) {
                    startSdk();
                } else {
                    stopSdk();
                }
            }
        });

        startStopSendingBtn.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View v) {
                /**
                 * A payload is a byte array dynamic size with a maximum size defined by the licence settings.
                 *
                 * Generate a random payload, and send it.
                 */
                long maxPayloadLength =10000;
                //long maxPayloadLength = chirpConnect.getMaxPayloadLength();
                //long size = (long) new Random().nextInt((int) maxPayloadLength) + 1;
                long size =50;
                String name =username.getText().toString() ;
                String cell=userphone.getText().toString() ;
                String addr=usercom.getText().toString() ;

                String[] inf;
                inf= new String[4];
                inf[1]=name;
                inf[2]=cell;
                inf[3]=addr;

                //byte[] payload = chirpConnect.randomPayload(size);

                //byte[] payload=name.getBytes();
                long maxSize = 50;
                // long maxSize = chirpConnect.getMaxPayloadLength();
                for(i=1; i<=3; i++) {
                    Log.i("ConnectError: ", "time" + i);
                    byte[] payload = inf[i].getBytes();

                    if (maxSize < payload.length) {
                        Log.e("ConnectError: ", "Invalid Payload");
                        return;

                    }
                    if(i<=3) {
                        payload = inf[i].getBytes();
                        ChirpError error = chirpConnect.send(payload);
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        chirpConnect.stop();
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        chirpConnect.start();
                        // ChirpError error2 = chirpConnect.send(payload);

                        if (error.getCode() > 0) {
                            Log.e("ConnectError: ", error.getMessage());
                        }
                    }

                }
            }
        });

        return v;
    }

    public void onResume() {
        super.onResume();

        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.RECORD_AUDIO}, RESULT_REQUEST_RECORD_AUDIO);
        }
        else {
            if (startStopSdkBtnPressed) startSdk();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case RESULT_REQUEST_RECORD_AUDIO: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (startStopSdkBtnPressed) stopSdk();
                }
                return;
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        chirpConnect.stop();
    }

    public void updateStatus(final String newStatus) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                status.setText(newStatus);
            }
        });
    }
    public void updateLastPayload(final String newPayload) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                lastChirp.setText(newPayload);
            }
        });
    }

    public void stopSdk() {
        ChirpError error = chirpConnect.stop();
        if (error.getCode() > 0) {
            Log.e("ConnectError: ", error.getMessage());
            return;
        }
        startStopSendingBtn.setAlpha(.4f);
        startStopSendingBtn.setClickable(false);
        startStopSdkBtn.setText("Start Sdk");
    }

    public void startSdk() {
        ChirpError error = chirpConnect.start();
        if (error.getCode() > 0) {
            Log.e("ConnectError: ", error.getMessage());
            return;
        }
        startStopSendingBtn.setAlpha(1f);
        startStopSendingBtn.setClickable(true);
        startStopSdkBtn.setText("Stop Sdk");
    }

//    public void startStopSdk(View view) {
//        /**
//         * Start or stop the SDK.
//         * Audio is only processed when the SDK is running.
//         */
//        startStopSdkBtnPressed = true;
//        if (chirpConnect.getConnectState() == ConnectState.AudioStateStopped) {
//            startSdk();
//        } else {
//            stopSdk();
//        }
//    }
//
//    public void sendPayload(View view) throws UnsupportedEncodingException, InterruptedException {
//        /**
//         * A payload is a byte array dynamic size with a maximum size defined by the licence settings.
//         *
//         * Generate a random payload, and send it.
//         */
//        long maxPayloadLength =10000;
//        //long maxPayloadLength = chirpConnect.getMaxPayloadLength();
//        //long size = (long) new Random().nextInt((int) maxPayloadLength) + 1;
//        long size =50;
//        String name =username.getText().toString() ;
//        String cell=userphone.getText().toString() ;
//        String addr=usercom.getText().toString() ;
//
//        String[] inf;
//        inf= new String[4];
//        inf[1]=name;
//        inf[2]=cell;
//        inf[3]=addr;
//
//        //byte[] payload = chirpConnect.randomPayload(size);
//
//        //byte[] payload=name.getBytes();
//        long maxSize = 50;
//        // long maxSize = chirpConnect.getMaxPayloadLength();
//        for(i=1; i<=3; i++) {
//            Log.i("ConnectError: ", "time" + i);
//            byte[] payload = inf[i].getBytes();
//
//            if (maxSize < payload.length) {
//                Log.e("ConnectError: ", "Invalid Payload");
//                return;
//
//            }
//            if(i<=3) {
//                payload = inf[i].getBytes();
//                ChirpError error = chirpConnect.send(payload);
//                Thread.sleep(3000);
//                chirpConnect.stop();
//                Thread.sleep(1000);
//                chirpConnect.start();
//                // ChirpError error2 = chirpConnect.send(payload);
//
//                if (error.getCode() > 0) {
//                    Log.e("ConnectError: ", error.getMessage());
//                }
//            }
//
//        }
//     }


}
