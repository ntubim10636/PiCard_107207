package com.example.ntub.myapplication;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;
import static java.lang.Integer.parseInt;


/**
 * A simple {@link Fragment} subclass.
 */
public class MemberFragment extends Fragment {

    SharedPreferences spref;

    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn= connectionDB.CONN();
    public String old_pwd;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("會員資料編輯");
        final View v=inflater.inflate(R.layout.fragment_member, container, false);

        final Button send_pwd=v.findViewById(R.id.send_pwd);
        Button e_close=v.findViewById(R.id.submit_close);
        final Button e_edit=v.findViewById(R.id.submit_edit);
        final TextView pwd_ck=v.findViewById(R.id.pwd_ck);

        final ScrollView form_block =v.findViewById(R.id.edit_form);
        final TextView e_pwd=v.findViewById(R.id.edit_pwd);
        final TextView e_email=v.findViewById(R.id.edit_email);
        final TextView e_name=v.findViewById(R.id.edit_name);
        final TextView e_tel=v.findViewById(R.id.edit_tel);
        final TextView e_cell=v.findViewById(R.id.edit_cell);
        final TextView e_line=v.findViewById(R.id.edit_line);


        form_block.setVisibility(View.GONE);
        e_edit.setVisibility(View.GONE);
        spref = getActivity().getSharedPreferences(KEY,MODE_PRIVATE);


        send_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Statement stmt=null;
                    stmt=conn.createStatement();
                    final ResultSet t=stmt.executeQuery("Select * from member where member_id ='"+spref.getString("userID","")+"'");
                    t.next();

                    String pwd_str= pwd_ck.getText().toString().trim();;
                    old_pwd=t.getString("member_pwd").trim();

                    if (pwd_str.trim().equalsIgnoreCase(t.getString("member_pwd").trim())){
                        form_block.setVisibility(View.VISIBLE);
                        pwd_ck.setVisibility(View.GONE);
                        send_pwd.setVisibility(View.GONE);
                        e_edit.setVisibility(View.VISIBLE);
                        e_pwd.setText(t.getString("member_pwd").trim());
                        e_email.setText(t.getString("member_email").trim());
                        e_name.setText(t.getString("member_name").trim());
                        e_tel.setText(t.getString("member_tel").trim());
                        e_cell.setText(t.getString("member_cel").trim());
                        if(t.getString("member_line")==null)
                            e_line.setText("");
                        else
                            e_line.setText(t.getString("member_line").trim());

                    }else{
                        Toast.makeText(getActivity(),"密碼輸入錯誤 \n 請重新輸入", Toast.LENGTH_LONG).show();
                    };
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });


        e_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.support.v4.app.FragmentTransaction ft=getFragmentManager().beginTransaction();
                ft.replace(R.id.screen_area,new SettingFragment()).addToBackStack(null);
                ft.commit();
            }
        });

        e_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    PreparedStatement preStatement=null ;

                    preStatement = conn.prepareStatement("Update member SET member_pwd=?,member_email=?,member_name=?,member_tel=?,member_cel=?,member_line=? where member_id=?");
                    preStatement.setString(1,e_pwd.getText().toString().trim());
                    preStatement.setString(2,e_email.getText().toString().trim());
                    preStatement.setString(3,e_name.getText().toString().trim());
                    preStatement.setString(4,e_tel.getText().toString().trim());
                    preStatement.setString(5,e_cell.getText().toString().trim());
                    preStatement.setString(6,e_line.getText().toString().trim());
                    preStatement.setString(7,spref.getString("userID","").trim());

                    int result = preStatement.executeUpdate();

                    if(!old_pwd.equalsIgnoreCase(e_pwd.getText().toString().trim())){
                        spref = getActivity().getSharedPreferences(KEY,MODE_PRIVATE);
                        spref.edit().clear().commit();

                        Intent intent = new Intent();
                        intent.setClass(getActivity(),LoginActivity.class);
                        startActivity(intent);
                        Toast.makeText(getActivity(),"修改密碼 \n 請重新登入", Toast.LENGTH_LONG).show();
                    }else{
                        android.support.v4.app.FragmentTransaction ft=getFragmentManager().beginTransaction();
                        ft.replace(R.id.screen_area,new SettingFragment()).addToBackStack(null);
                        ft.commit();

                        Toast.makeText(getActivity(),"已修改個人資料", Toast.LENGTH_LONG).show();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });




        return v;
    }

}
