package com.example.ntub.myapplication;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.app.LoaderManager.LoaderCallbacks;

import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.READ_CONTACTS;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    /**
     * Id to identity READ_CONTACTS permission request.
     */
    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn= connectionDB.CONN();
    PreparedStatement stmt;
    ResultSet rs;
    String mid;

    public static final String KEY = "userInfo";
    SharedPreferences spref;


      private static final int REQUEST_READ_CONTACTS = 0;

    /**
     * A dummy authentication store containing known user names and passwords.
     * TODO: remove after connecting to a real authentication system.
     */
    private static final String[] DUMMY_CREDENTIALS = new String[]{
            "foo@example.com:hello", "bar@example.com:world"
    };
    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */


    // UI references.
    private AutoCompleteTextView mEmailView;
    private EditText mPasswordView;
    private View mProgressView,mLoginFormView;
    private  TextView mWelComeUserView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Set up the login form.

        spref = getApplication().getSharedPreferences(KEY,MODE_PRIVATE);

        mEmailView = (AutoCompleteTextView) findViewById(R.id.email);
        mPasswordView = (EditText) findViewById(R.id.password);
        mWelComeUserView = findViewById(R.id.userInfo);

        Button sign_in = (Button) findViewById(R.id.signin_btn);
        Button mEmaillogInButton = (Button) findViewById(R.id.email_sign_in_button);


        if(spref.getBoolean("isLogin",false)){
            mEmailView.setVisibility(View.GONE);
            mPasswordView.setVisibility(View.GONE);
            mWelComeUserView.setVisibility(View.VISIBLE);
            mWelComeUserView.setText("Hi "+spref.getString("userID",""));
            sign_in.setVisibility(View.GONE);
            mEmaillogInButton.setVisibility(View.GONE);
            mHandler.sendEmptyMessageDelayed(0, 3000);//3秒跳轉
        }


        mEmaillogInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String  email=mEmailView.getText().toString();
                String  pwd =mPasswordView.getText().toString();
                String smid="",spwd="",sname="";

                String query = "SELECT * FROM member Where member_id= '"+email+"'";

                //status.setText(query);
                try {

                    stmt = conn.prepareStatement(query);
                    rs = stmt.executeQuery();
                    rs.next();
                    smid=rs.getString("member_id").trim();
                    spwd=rs.getString("member_pwd").trim();
                    sname=rs.getString("member_name").trim();


                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if(email.equalsIgnoreCase("") && pwd.equalsIgnoreCase("")){
                    Toast.makeText(LoginActivity.this,"帳號或密碼未輸入", Toast.LENGTH_LONG).show();
                }
                else if(email.equalsIgnoreCase(smid) && pwd.equalsIgnoreCase(spwd)){
                    Intent MainIntent = new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(MainIntent);
                    spref.edit().putBoolean("isLogin", true)
                            .putString("userID", email.toString())
                            .putString("userName", sname.toString())
                            .commit();
                    Toast.makeText(LoginActivity.this,"登入成功", Toast.LENGTH_LONG).show();

                }
                else{
                    Toast.makeText(LoginActivity.this,"登入失敗", Toast.LENGTH_LONG).show();
                }



            }
        });
        /******************註冊按鈕*******************/
        sign_in.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, sign_in.class));
            }
        });

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
    }
    private Handler mHandler = new Handler(){

        public void handleMessage(android.os.Message msg) {

            switch (msg.what) {

                case 0:
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    break;
                default:

                    break;

            }

        };

    };
}


