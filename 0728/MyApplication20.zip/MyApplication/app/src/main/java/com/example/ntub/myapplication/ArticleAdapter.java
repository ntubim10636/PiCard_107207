package com.example.ntub.myapplication;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ArticleAdapter extends BaseAdapter {

    private Context mcontent;
    private List<Article> mArticleList;

    public ArticleAdapter(Context mcontent, List<Article> mArticleList) {
        this.mcontent = mcontent;
        this.mArticleList = mArticleList;
    }

    public class Holder{
        TextView tvTitle;
        TextView tvAuthor;
        TextView tvType;
        TextView tvDate;
        TextView tvStarNum;
        ImageButton isCollectImg;
    }

    @Override
    public int getCount() {
        return mArticleList.size();
    }

    @Override
    public Object getItem(int position) {
        return mArticleList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        View v=View.inflate(mcontent,R.layout.item_article_list,null);
        TextView tvTitle=v.findViewById(R.id.tv_title);
        TextView tvAuthor=v.findViewById(R.id.tv_author);
        TextView tvType=v.findViewById(R.id.tv_type);
        TextView tvDate=v.findViewById(R.id.tv_date);
        TextView tvStarNum=v.findViewById(R.id.tv_star_num);
        ImageButton isCollectImg=(ImageButton)v.findViewById(R.id.img_star);

        isCollectImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ListView) parent).performItemClick(v, position, 0); // Let the event be handled in onItemClick()
            }
        });

        tvTitle.setText(mArticleList.get(position).getTitle());
        tvAuthor.setText(mArticleList.get(position).getAuthor());
        tvStarNum.setText(""+mArticleList.get(position).getStar_num());
        tvDate.setText(""+mArticleList.get(position).getCreateDate());
        switch (mArticleList.get(position).getTypeA()){
            case 1:
                tvType.setText("[徵才]");
                break;
            case 2:
                tvType.setText("[心得]");
                break;
            case 3:
                tvType.setText("[活動]");
                break;
            default:
                tvType.setText("");
                 break;
        }

        if(mArticleList.get(position).getisCollect()){
            isCollectImg.setImageResource(R.drawable.ic_star_black_24dp_y);
            isCollectImg.setTag(R.id.IBimg,R.drawable.ic_star_black_24dp_y);
            isCollectImg.setTag(R.id.A_id,mArticleList.get(position).getId());
        }else{
            isCollectImg.setImageResource(R.drawable.ic_star_border_black_24dp);
            isCollectImg.setTag(R.id.IBimg,R.drawable.ic_star_border_black_24dp);
            isCollectImg.setTag(R.id.A_id,mArticleList.get(position).getId());
        }

        v.setTag(R.id.item_A_id,mArticleList.get(position).getId());
        v.setTag(R.id.item_A_title,mArticleList.get(position).getTitle());
        v.setTag(R.id.item_A_author,mArticleList.get(position).getAuthor());
        v.setTag(R.id.item_A_content,mArticleList.get(position).getContent());
        v.setTag(R.id.item_A_createDate,mArticleList.get(position).getCreateDate());
        v.setTag(R.id.item_A_typeA,mArticleList.get(position).getTypeA());
        v.setTag(R.id.item_A_star_num,mArticleList.get(position).getStar_num());
        v.setTag(R.id.item_A_isCollect,mArticleList.get(position).getisCollect());

        return v;
    }

    public void refreshArticles(List<Article> mArticleList) {
        this.mArticleList.clear();
        this.mArticleList.addAll(mArticleList);
        notifyDataSetChanged();
    }
}
