package com.example.ntub.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static android.app.PendingIntent.getActivity;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.ntub.myapplication.LoginActivity.KEY;
import static java.lang.Integer.parseInt;

public class EditArticle extends AppCompatActivity {

    public int a_Type=0;
    SharedPreferences spref;

    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        conn= connectionDB.CONN();


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_article);

        Toolbar toolbar = (Toolbar) findViewById(R.id.singInBar_A);
        toolbar.setTitle("編輯文章");

        spref = this.getApplication().getSharedPreferences(KEY,MODE_PRIVATE);
        final Intent i = getIntent();

        Spinner mSpn = (Spinner) findViewById(R.id.selectType);
        List<String> MyAtype = new ArrayList<String>();
        MyAtype.add("徵才");
        MyAtype.add("心得");
        MyAtype.add("活動");

        ArrayAdapter<String> AtypeList = new ArrayAdapter<String>(this, R.layout.spinner_item, MyAtype);

        mSpn.setAdapter(AtypeList);
        AtypeList.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AtypeList.notifyDataSetChanged();
        mSpn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        a_Type=1;
                        break;
                    case 1:
                        a_Type=2;
                        break;
                    case 2:
                        a_Type=3;
                        break;
                    default:
                        a_Type=0;
                        break;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(new EditArticle(),"test"+parseInt(a_Type+""), LENGTH_SHORT).show();
            }
        });

        Button btn_edit=findViewById(R.id.submit_btn_A);
        Button btn_del=findViewById(R.id.delete_A);

        final TextView etv_title=findViewById(R.id.etv_Atitle);
        final TextView etv_C=findViewById(R.id.etv_Acontent);

        final SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        java.util.Date date_j=new java.util.Date();
        String data_srt=sdFormat.format(date_j);
        //Timestamp d = new Timestamp(System.currentTimeMillis());
        Date sqldate = null;
        try {
            sqldate = new Date(sdFormat.parse(data_srt).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }


        if(parseInt(i.getStringExtra("A_id"))==0)
        {
            mSpn.setSelection(0);
            btn_edit.setText("新增");
            btn_del.setVisibility(View.GONE);

            final Date finalSqldate = sqldate;
            btn_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PreparedStatement preStatement=null ;
                    try {
                        preStatement = conn.prepareStatement("Insert into article(article_title,article_content,article_date,article_mid,article_type)VALUES (?,?,?,?,?)");
                        preStatement.setString(1,etv_title.getText().toString());
                        preStatement.setString(2,etv_C.getText().toString());
                        preStatement.setDate(3, finalSqldate);
                        preStatement.setString(4,spref.getString("userID",""));
                        preStatement.setInt(5, a_Type);
                        int result = preStatement.executeUpdate();

                        Toast.makeText(EditArticle.this,"已新增文章", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(EditArticle.this, MainActivity.class);
                        intent.putExtra("isEditReturn",1);
                        startActivity(intent);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                }
            });

        }else {
            mSpn.setSelection(parseInt(i.getStringExtra("A_type"))-1);
            etv_title.setText(i.getStringExtra("A_title"));
            etv_C.setText(i.getStringExtra("A_content"));
            btn_edit.setText("儲存");
            btn_del.setVisibility(View.VISIBLE);

            btn_del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PreparedStatement preStatement=null ;
                    try {
                        preStatement = conn.prepareStatement("Delete from article where article_id=?");
                        preStatement.setInt(1, parseInt(i.getStringExtra("A_id")));
                        int result = preStatement.executeUpdate();
                        Toast.makeText(EditArticle.this,"已刪除文章", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(EditArticle.this, MainActivity.class);
                        intent.putExtra("isEditReturn",1);
                        startActivity(intent);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            });

            final Date finalSqldate1 = sqldate;
            btn_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PreparedStatement preStatement=null ;
                    try {
                        preStatement = conn.prepareStatement("Update article SET article_title=?,article_date=?,article_type=?,article_content=? where article_id=?");
                        preStatement.setString(1,etv_title.getText().toString());
                        preStatement.setDate(2, finalSqldate1);
                        preStatement.setInt(3, a_Type);
                        preStatement.setString(4,etv_C.getText().toString());
                        preStatement.setInt(5, parseInt(i.getStringExtra("A_id")));
                        int result = preStatement.executeUpdate();
                        Toast.makeText(EditArticle.this,"已編輯文章", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent();
                        intent.setClass(EditArticle.this,MainActivity.class);
                        intent.putExtra("isEditReturn",1);
                        startActivity(intent);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                }
            });
        }


        //Toast.makeText(this,"test"+parseInt(i.getStringExtra("A_id")), LENGTH_SHORT).show();

        setSupportActionBar(toolbar);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_close, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.returnArticleList :
                Intent intent = new Intent();
                intent.setClass(this,MainActivity.class);
                intent.putExtra("isEditReturn",1);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
