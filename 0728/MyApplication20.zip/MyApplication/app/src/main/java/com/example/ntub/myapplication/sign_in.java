package com.example.ntub.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.StrictMode;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import android.support.v7.widget.Toolbar;
import java.sql.Statement;
import java.util.ArrayList;

import static com.example.ntub.myapplication.LoginActivity.KEY;


public class sign_in extends AppCompatActivity {
    EditText member_id,member_pwd,member_email,member_name,member_tel,member_cell,member_line;
   // EditText status;
    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn= connectionDB.CONN();
    PreparedStatement stmt;
    int rs;
    String mid;
    SharedPreferences spref;


    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);


       // status = (EditText) findViewById(R.id.editText);
        member_id=(EditText) findViewById(R.id.member_id);
        member_pwd=(EditText) findViewById(R.id.member_pwd);
        member_email=(EditText) findViewById(R.id.member_email);
        member_name=(EditText) findViewById(R.id.member_name);
        member_tel=(EditText) findViewById(R.id.member_tel);
        member_cell=(EditText) findViewById(R.id.member_cell);
        member_line=(EditText) findViewById(R.id.member_line);

        spref = getApplication().getSharedPreferences(KEY,MODE_PRIVATE);

        Toolbar toolbar = (Toolbar) findViewById(R.id.singInBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        Button submit_btn = (Button) findViewById(R.id.submit_btn);

        /******************送出按鈕*******************/
        submit_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String mid=member_id.getText().toString();
                String mpwd=member_pwd.getText().toString();
                String memail=member_email.getText().toString();
                String mname=member_name.getText().toString();
                String mtel=member_tel.getText().toString();
                String mcell=member_cell.getText().toString();
                String mline=member_line.getText().toString();


                String query = "INSERT INTO member" +
                        " (member_id, member_pwd, member_email, member_name, member_tel, member_cel, member_line)" +
                        "VALUES ('"+mid+"','"+mpwd+"' ,'"+memail+"' ,'"+mname+"' ,'"+mtel+"' ,'"+mcell+"','"+mline+"' )";

               // status.setText(query);
                try {
                    stmt = conn.prepareStatement(query);
                    rs = stmt.executeUpdate();

                    Toast.makeText(sign_in.this,"註冊成功", Toast.LENGTH_LONG).show();

                    spref.edit().putBoolean("isLogin", true)
                            .putString("userID", mid.toString())
                            .putString("userName", mname.toString())
                            .commit();

                    Intent intent = new Intent();
                    intent.setClass(sign_in.this, MainActivity.class);
                    startActivity(intent);
                    finish();


                } catch (SQLException e) {
                    e.printStackTrace();
                }



            }
        });


    }

}
