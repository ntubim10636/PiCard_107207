package com.example.ntub.myapplication;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import javax.xml.transform.Templates;


/**
 * A simple {@link Fragment} subclass.
 */
public class ShowArticleFragment extends Fragment {


    public ShowArticleFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_show_article, container, false);
        Bundle bundle = getArguments();
        String displayAtype=null;

        switch (bundle.getInt("A_type")){
            case 1:
                displayAtype="[徵才]";
                break;
            case 2:
                displayAtype="[心得]";
                break;
            case 3:
                displayAtype="[活動]";
                break;
            default:
                displayAtype="";
                break;
        }

        ((MainActivity)getActivity()).setActionBarTitle(displayAtype +" "+bundle.getString("A_title"));
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle(bundle.getString("A_author"));

        TextView tv_title=v.findViewById(R.id.show_title);
        TextView tv_author=v.findViewById(R.id.show_author);
        TextView tv_num=v.findViewById(R.id.show_star_num);
        TextView tv_date=v.findViewById(R.id.show_date);
        TextView tv_content=v.findViewById(R.id.tv_content);

        tv_title.setText(displayAtype +" "+bundle.getString("A_title"));
        tv_author.setText(bundle.getString("A_author"));
        tv_num.setText(bundle.getInt("A_Star")+"");
        tv_date.setText(bundle.getString("A_date"));
        tv_content.setText(bundle.getString("A_content"));

        return v;
    }

}
