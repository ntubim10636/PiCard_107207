package com.example.ntub.myapplication;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.ListView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

import static java.lang.Integer.parseInt;

public class getArticles  {
    MSSQLconnection connectionDB=new MSSQLconnection();

    public List<Article> getAllArticles(String db_query,String userID){
        List<Article> articleList =new ArrayList<Article>();

        Connection conn;
        conn= connectionDB.CONN();
        Statement stmt=null,stmt_s=null,stmt_ms=null;

        try {
            Boolean TorF=false;
            stmt=conn.createStatement();
            stmt_s=conn.createStatement();
            stmt_ms=conn.createStatement();
            Log.i("database",stmt.toString());
            ResultSet t=stmt.executeQuery(db_query);
            SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");

            t.next();

            do{
                ResultSet stmt_sq=stmt_s.executeQuery("select count(member_id) as num from collectTable where article_id="+parseInt(t.getString(1)));
                stmt_sq.next();
                ResultSet stmt_ms_sq=stmt_ms.executeQuery("Select * from collectTable where member_id='"+userID+"' AND article_id="+parseInt(t.getString(1)));

                if (stmt_ms_sq.next()){
                    TorF=true;
                } else {
                    TorF=false;
                }

                Article Alist_item=new Article(parseInt(t.getString(1)),t.getString(2),t.getString(5),t.getString(3),sdFormat.format(t.getDate(4)),parseInt(t.getString(6)),stmt_sq.getInt("num"),TorF);
                articleList.add(Alist_item);
                Log.i("databaseAATEST",t.getString(1));
            }while (t.next());


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articleList;
    }

}
