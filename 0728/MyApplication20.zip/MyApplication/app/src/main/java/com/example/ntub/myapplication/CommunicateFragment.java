package com.example.ntub.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static android.app.ProgressDialog.show;
import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;
import static java.lang.Integer.parseInt;

/**
 * A simple {@link Fragment} subclass.
 */
public class CommunicateFragment extends Fragment {
    SharedPreferences  spref;
    private ListView lvArticle;
    private ArticleAdapter adapter;
 //   private boolean success= false;
  //  private MSSQLconnection sqlConn;
 //   public int f_num;
    public static List currentArticleList;

    public CommunicateFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("交流專區");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");

        spref = getActivity().getApplication().getSharedPreferences(KEY,MODE_PRIVATE);
        setHasOptionsMenu(true);

        View v=inflater.inflate(R.layout.fragment_communicate, container, false);
        v.findViewById(R.id.set_list_op).setVisibility(View.VISIBLE);

        Spinner mSpn = (Spinner) v.findViewById(R.id.selectType);
        List<String> MyAtype = new ArrayList<String>();
        MyAtype.add("全部");
        MyAtype.add("徵才");
        MyAtype.add("心得");
        MyAtype.add("活動");

        ArrayAdapter<String> AtypeList = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, MyAtype);

        mSpn.setAdapter(AtypeList);
        AtypeList.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AtypeList.notifyDataSetChanged();


        mSpn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        currentArticleList=new getArticles().getAllArticles("Select * from article where article_type=1  order by article_date DESC",spref.getString("userID",""));
                        adapter.refreshArticles(new getArticles().getAllArticles("Select * from article where article_type=1  order by article_date DESC",spref.getString("userID","")));
                        break;
                    case 2:
                        currentArticleList=new getArticles().getAllArticles("Select * from article where article_type=2  order by article_date DESC",spref.getString("userID",""));
                        adapter.refreshArticles(new getArticles().getAllArticles("Select * from article where article_type=2  order by article_date DESC",spref.getString("userID","")));
                        break;
                    case 3:
                        currentArticleList=new getArticles().getAllArticles("Select * from article where article_type=3  order by article_date DESC",spref.getString("userID",""));
                        adapter.refreshArticles(new getArticles().getAllArticles("Select * from article where article_type=3  order by article_date DESC",spref.getString("userID","")));
                        break;
                    default:
                        currentArticleList=new getArticles().getAllArticles("Select * from article order by article_date DESC",spref.getString("userID",""));
                        adapter.refreshArticles(new getArticles().getAllArticles("Select * from article order by article_date DESC",spref.getString("userID","")));
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getActivity(), "NO SELECT", Toast.LENGTH_SHORT).show();
            }
        });

        RadioButton dateButton = (RadioButton) v.findViewById(R.id.by_date);
        RadioButton starButton = (RadioButton) v.findViewById(R.id.by_star);
        RadioGroup sortRadioGroup = (RadioGroup) v.findViewById(R.id.sort_method);
        sortRadioGroup.check(R.id.by_date);
        sortRadioGroup.setOnCheckedChangeListener(sortRadioGroupOnCheckedChange); //設定單選選項監聽器

        lvArticle=v.findViewById(R.id.list_article);
        currentArticleList=new getArticles().getAllArticles("Select * from article order by article_date DESC",spref.getString("userID",""));
        adapter = new ArticleAdapter(getActivity(),new getArticles().getAllArticles("Select * from article order by article_date DESC",spref.getString("userID","")));

        lvArticle.setAdapter(adapter);

        lvArticle.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                long viewId = view.getId();

                if (viewId == R.id.img_star) {
                    ImageButton IB =view.findViewById((int) viewId);
                    Integer resource = (Integer) IB.getTag(R.id.IBimg);

                    MSSQLconnection connectionDB=new MSSQLconnection();

                    Connection conn;
                    conn= connectionDB.CONN();
                    PreparedStatement preStatement=null ;

                    if(resource == R.drawable.ic_star_black_24dp_y){
                        IB.setImageResource(R.drawable.ic_star_border_black_24dp);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_border_black_24dp);;

                        try {
                            preStatement = conn.prepareStatement("Delete from collectTable where member_id=? AND article_id=?");
                            preStatement.setString(1,spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(currentArticleList);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }else {
                        IB.setImageResource(R.drawable.ic_star_black_24dp_y);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_black_24dp_y);;
                        try {
                            preStatement = conn.prepareStatement("INSERT INTO collectTable VALUES (?,?)");
                            preStatement.setString(1, spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(currentArticleList);
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }

                }else{
                    Bundle bundle=new Bundle();
                    bundle.putInt("A_id",parseInt(view.getTag(R.id.item_A_id)+""));
                    bundle.putString("A_title",view.getTag(R.id.item_A_title)+"");
                    bundle.putString("A_author",view.getTag(R.id.item_A_author)+"");
                    bundle.putInt("A_Star",parseInt(view.getTag(R.id.item_A_star_num)+""));
                    bundle.putString("A_date",view.getTag(R.id.item_A_createDate)+"");
                    bundle.putString("A_content",view.getTag(R.id.item_A_content)+"");
                    bundle.putInt("A_type",parseInt(view.getTag(R.id.item_A_typeA)+""));

                    android.support.v4.app.FragmentTransaction ft=getFragmentManager().beginTransaction();
                    ShowArticleFragment f =new ShowArticleFragment();
                    f.setArguments(bundle);
                    ft.replace(R.id.screen_area,f).addToBackStack(null);
                    ft.commit();

                }
            }
        });

        return v;
    }

    private RadioGroup.OnCheckedChangeListener sortRadioGroupOnCheckedChange =
            new RadioGroup.OnCheckedChangeListener()
            {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId)
                {
                    // TODO Auto-generated method stub
                    switch (checkedId)
                    {
                        case R.id.by_date:
                            final SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
                            Collections.sort(currentArticleList, new Comparator<Article>() {
                                public int compare(Article a1, Article a2) {
                                    if (a1.getCreateDate() == null || a2.getCreateDate() == null)
                                        return 0;
                                    try {
                                        return sdFormat.parse(a2.getCreateDate()).compareTo(sdFormat.parse(a1.getCreateDate()));
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                    return 0;
                                }
                            });
                            adapter.refreshArticles(currentArticleList);
                            break;
                        case R.id.by_star:
                            Collections.sort(currentArticleList, new Comparator<Article>(){
                                public int compare(Article a1,Article a2){
                                    return  Integer.valueOf(a2.getStar_num()-a1.getStar_num());
                                }
                            });
                            adapter.refreshArticles(currentArticleList);
                            break;
                        default:
                            break;
                    }
                }
            };

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.communicate_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout :
                spref.edit().clear().commit();

                Intent intent = new Intent();
                intent.setClass((MainActivity)getActivity(),LoginActivity.class);
                startActivity(intent);
                Toast.makeText((MainActivity)getActivity(),"已登出", Toast.LENGTH_LONG).show();
                return true;
            case R.id.editArticle :
                android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.screen_area,new MyArticleFragment()).addToBackStack(null);
                ft.commit();
                return true;
            case R.id.editCollect :
                android.support.v4.app.FragmentTransaction ftc=getActivity().getSupportFragmentManager().beginTransaction();
                ftc.replace(R.id.screen_area,new MyCollectArticleFragment()).addToBackStack(null);
                ftc.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
