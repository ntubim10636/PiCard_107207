package com.example.ntub.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static android.app.ProgressDialog.show;
import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;
import static java.lang.Integer.parseInt;

/**
 * A simple {@link Fragment} subclass.
 */
public class MyCollectArticleFragment extends Fragment {
    SharedPreferences  spref;
    private ListView lvArticle;
    private ArticleAdapter adapter;
    private List<Article> mArticleList;
    private boolean success= false;
    private MSSQLconnection sqlConn;
    public int f_num;


    public MyCollectArticleFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("交流專區");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");

        spref = getActivity().getApplication().getSharedPreferences(KEY,MODE_PRIVATE);
        setHasOptionsMenu(true);


        View v=inflater.inflate(R.layout.fragment_my_collect_article, container, false);

        lvArticle=v.findViewById(R.id.list_article);
        mArticleList=new ArrayList<>();

        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        adapter = new ArticleAdapter(getActivity(),new getArticles().getAllArticles("Select * from article T1 ,(Select * from  collectTable where member_id='"+spref.getString("userID","")+"') T2 Where T1.article_id=T2.article_id",spref.getString("userID","")));

        lvArticle.setAdapter(adapter);

        lvArticle.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                long viewId = view.getId();

                if (viewId == R.id.img_star) {
                    ImageButton IB =view.findViewById((int) viewId);
                    Integer resource = (Integer) IB.getTag(R.id.IBimg);

                    MSSQLconnection connectionDB=new MSSQLconnection();

                    Connection conn;
                    conn= connectionDB.CONN();
                    PreparedStatement preStatement=null ;

                    if(resource == R.drawable.ic_star_black_24dp_y){
                        Toast.makeText(getActivity(), "T to F", Toast.LENGTH_SHORT).show();
                        IB.setImageResource(R.drawable.ic_star_border_black_24dp);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_border_black_24dp);;

                        try {
                            preStatement = conn.prepareStatement("Delete from collectTable where member_id=? AND article_id=?");
                            preStatement.setString(1,spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(new getArticles().getAllArticles("Select * from article T1 ,(Select * from  collectTable where member_id='"+spref.getString("userID","")+"') T2 Where T1.article_id=T2.article_id",spref.getString("userID","")));
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }else {
                        Toast.makeText(getActivity(), "F to T", Toast.LENGTH_SHORT).show();
                        IB.setImageResource(R.drawable.ic_star_black_24dp_y);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_black_24dp_y);;
                        try {
                            preStatement = conn.prepareStatement("INSERT INTO collectTable VALUES (?,?)");
                            preStatement.setString(1, spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(new getArticles().getAllArticles("Select * from article T1 ,(Select * from  collectTable where member_id='"+spref.getString("userID","")+"') T2 Where T1.article_id=T2.article_id",spref.getString("userID","")));
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }else{

                    Bundle bundle=new Bundle();
                    bundle.putInt("A_id",parseInt(view.getTag(R.id.item_A_id)+""));
                    bundle.putString("A_title",view.getTag(R.id.item_A_title)+"");
                    bundle.putString("A_author",view.getTag(R.id.item_A_author)+"");
                    bundle.putInt("A_Star",parseInt(view.getTag(R.id.item_A_star_num)+""));
                    bundle.putString("A_date",view.getTag(R.id.item_A_createDate)+"");
                    bundle.putString("A_content",view.getTag(R.id.item_A_content)+"");
                    bundle.putInt("A_type",parseInt(view.getTag(R.id.item_A_typeA)+""));

                    android.support.v4.app.FragmentTransaction ft=getFragmentManager().beginTransaction();
                    ShowArticleFragment f =new ShowArticleFragment();
                    f.setArguments(bundle);
                    ft.replace(R.id.screen_area,f).addToBackStack(null);
                    ft.commit();

                }

            }
        });

        return v;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.communicate_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout :
                spref.edit().clear().commit();

                Intent intent = new Intent();
                intent.setClass((MainActivity)getActivity(),LoginActivity.class);
                startActivity(intent);
                Toast.makeText((MainActivity)getActivity(),"已登出", Toast.LENGTH_LONG).show();
                return true;
            case R.id.editArticle :
                android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.screen_area,new MyArticleFragment()).addToBackStack(null);
                ft.commit();
                return true;
            case R.id.editCollect :
                android.support.v4.app.FragmentTransaction ftC=getActivity().getSupportFragmentManager().beginTransaction();
                ftC.replace(R.id.screen_area,new CommunicateFragment()).addToBackStack(null);
                ftC.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
