package com.example.ntub.myapplication;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;


/**
 * A simple {@link Fragment} subclass.
 */
public class editmycard extends Fragment {
    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn= connectionDB.CONN();
    PreparedStatement stmt,stmt2;
    int rs;
    ResultSet rs2;

    SharedPreferences spref;


    EditText etv_name;
    EditText etv_com_tel;
    EditText etv_com_fax;
    EditText etv_cell;
    EditText etv_email;
    EditText etv_comname;
    EditText etv_position;
    EditText etv_addr;
    EditText etv_url;
    EditText etv_line;
    EditText etv_video;
    EditText etv_template;
    EditText etv_service;
    Button send;

    String cardid="";
    String name;
    String tel;
    String fax;
    String cell;
    String email;
    String comname;
    String position;
    String addr;
    String url ;
    String line;
    String video;
    String template;
    String service;


    public editmycard() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((MainActivity) getActivity()).setActionBarTitle("編輯名片");
        ((MainActivity) getActivity()).getSupportActionBar().setSubtitle("");
        spref = getActivity().getApplication().getSharedPreferences(KEY, MODE_PRIVATE);
        setHasOptionsMenu(true);
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_editmycard, container, false);
        View v = inflater.inflate(R.layout.fragment_editmycard, container, false);

        etv_name = (EditText) v.findViewById(R.id.etv_name);
        etv_com_tel = (EditText) v.findViewById(R.id.etv_com_tel);
        etv_com_fax = (EditText) v.findViewById(R.id.etv_com_fax);
        etv_cell = (EditText) v.findViewById(R.id.etv_cell);
        etv_email = (EditText) v.findViewById(R.id.etv_email);
        etv_comname = (EditText) v.findViewById(R.id.etv_comname);
        etv_position = (EditText) v.findViewById(R.id.etv_position);
        etv_addr = (EditText) v.findViewById(R.id.etv_addr);
        etv_url = (EditText) v.findViewById(R.id.etv_url);
        etv_line = (EditText) v.findViewById(R.id.etv_line);
        etv_video = (EditText) v.findViewById(R.id.etv_video);
        etv_template = (EditText) v.findViewById(R.id.etv_template);
        etv_service = (EditText) v.findViewById(R.id.etv_service);
        send = (Button) v.findViewById(R.id.submit_btn_A);





        String query = "Select * from card where card_id ='"+spref.getString("userID","")+"'";

        try {
            stmt2 = conn.prepareStatement(query);
            rs2 = stmt2.executeQuery();
            rs2.next();

            cardid=rs2.getString("card_id").trim();
            name=rs2.getString("card_name").trim();
            tel=rs2.getString("card_tel").trim();
            fax=rs2.getString("card_fax").trim();
            cell=rs2.getString("card_cel").trim();
            email=rs2.getString("card_email").trim();
            comname=rs2.getString("card_company").trim();
            position=rs2.getString("card_title").trim();
            addr=rs2.getString("card_addr").trim();
            url=rs2.getString("card_url").trim();
            line=rs2.getString("card_line").trim();
            video=rs2.getString("card_video").trim();
            template=rs2.getString("card_template").trim();
            service=rs2.getString("card_service").trim();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        etv_name.setText(cardid);

        if(cardid.equalsIgnoreCase(spref.getString("userID",""))){
           etv_name.setText(name);
           etv_com_tel.setText(tel);
           etv_com_fax.setText(fax);
           etv_cell.setText(cell);
           etv_email.setText(email);
           etv_comname.setText(comname);
           etv_position.setText(position);
           etv_addr.setText(addr);
           etv_url.setText(url);
           etv_line.setText(line);
           etv_video.setText(video);
           etv_template.setText(template);
           etv_service.setText(service);
           send.setText("更新");


            send.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String userid = spref.getString("userID", "");
                    name = etv_name.getText().toString();
                    tel = etv_com_tel.getText().toString();
                    fax = etv_com_fax.getText().toString();
                    cell = etv_cell.getText().toString();
                    email = etv_email.getText().toString();
                    comname = etv_comname.getText().toString();
                    position = etv_position.getText().toString();
                    addr = etv_addr.getText().toString();
                    url = etv_url.getText().toString();
                    line = etv_line.getText().toString();
                    video = etv_video.getText().toString();
                    template = etv_template.getText().toString();
                    service = etv_service.getText().toString();

                    String query = "UPDATE card SET"+" card_name ='"+name+"',card_tel  ='"+tel+"',card_fax ='"+fax+"',card_cel ='"+cell+"',card_email = '"+email+"',card_company = '"+comname+"',card_title = '"+position+"',card_addr = '"+addr+"',card_url = '"+url+"',card_line = '"+line+"',card_video = '"+video+"',card_template = '"+template+"',card_service ='"+service+"' WHERE card_id='"+userid+"'";
                    try {
                        stmt = conn.prepareStatement(query);
                        rs = stmt.executeUpdate();

                        Toast.makeText(getActivity(), "更新成功", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent();
                        intent.setClass(getActivity(), MainActivity.class);
                        startActivity(intent);



                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                  //etv_name.setText(query);
                }
            });




        }
        else {

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userid = spref.getString("userID", "");
                name = etv_name.getText().toString();
                tel = etv_com_tel.getText().toString();
                fax = etv_com_fax.getText().toString();
                cell = etv_cell.getText().toString();
                email = etv_email.getText().toString();
                comname = etv_comname.getText().toString();
                position = etv_position.getText().toString();
                addr = etv_addr.getText().toString();
                url = etv_url.getText().toString();
                line = etv_line.getText().toString();
                video = etv_video.getText().toString();
                template = etv_template.getText().toString();
                service = etv_service.getText().toString();

                    String query = "INSERT INTO card" +
                            " ( card_id,card_name,card_tel,card_fax,card_cel,card_email,card_company,card_title,card_addr,card_url,card_line,card_video,card_template,card_service)" +
                            "VALUES ('" + userid + "','" + name + "' ,'" + tel + "' ,'" + fax + "' ,'" + cell + "' ,'" + email + "' ,'" + comname + "' ,'" + position + "' ,'" + addr + "' ,'" + url + "' ,'"  + line + "' ,'" + video + "' ,'" + template + "','" + service + "' )";
                    try {
                        stmt = conn.prepareStatement(query);
                        rs = stmt.executeUpdate();

                        Toast.makeText(getActivity(), "建立成功", Toast.LENGTH_LONG).show();

                        Intent intent = new Intent();
                        intent.setClass(getActivity(), MainActivity.class);
                        startActivity(intent);



                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
        }
    });

        }
        return v;

    }
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu_close, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.returnArticleList :
                Intent intent = new Intent();
                intent.setClass(getActivity(),MainActivity.class);
                intent.putExtra("isEditReturn",0);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
