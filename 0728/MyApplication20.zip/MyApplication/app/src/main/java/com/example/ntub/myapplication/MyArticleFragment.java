package com.example.ntub.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;
import static java.lang.Integer.parseInt;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyArticleFragment extends Fragment {
    SharedPreferences  spref;
    private ListView lvArticle;
    private ArticleAdapter adapter;
    private List<Article> mArticleList;
    private boolean success= false;
    private MSSQLconnection sqlConn;
    public int f_num;

    FloatingActionButton fab;

    public MyArticleFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity)getActivity()).setActionBarTitle("我的文章");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");
        View view =inflater.inflate(R.layout.fragment_my_article, container, false);

        fab=view.findViewById(R.id.addArticle);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),EditArticle.class);
                intent.putExtra("A_id","0");
                startActivity(intent);
            }
        });

        spref = getActivity().getSharedPreferences(KEY,MODE_PRIVATE);

        lvArticle=view.findViewById(R.id.list_article);
        mArticleList=new ArrayList<>();

        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        adapter = new ArticleAdapter(getActivity(),new getArticles().getAllArticles("Select * from article where article_mid='"+spref.getString("userID","")+"'",spref.getString("userID","")));

        lvArticle.setAdapter(adapter);

        lvArticle.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                long viewId = view.getId();

                if (viewId == R.id.img_star) {
                    ImageButton IB =view.findViewById((int) viewId);
                    Integer resource = (Integer) IB.getTag(R.id.IBimg);

                    MSSQLconnection connectionDB=new MSSQLconnection();

                    Connection conn;
                    conn= connectionDB.CONN();
                    PreparedStatement preStatement=null ;

                    if(resource == R.drawable.ic_star_black_24dp_y){
                        IB.setImageResource(R.drawable.ic_star_border_black_24dp);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_border_black_24dp);
                        try {
                            preStatement = conn.prepareStatement("Delete from collectTable where member_id=? AND article_id=?");
                            preStatement.setString(1,spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(new getArticles().getAllArticles("Select * from article where article_mid='"+spref.getString("userID","")+"'",spref.getString("userID","")));
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }else {
                        IB.setImageResource(R.drawable.ic_star_black_24dp_y);
                        IB.setTag(R.id.IBimg,R.drawable.ic_star_black_24dp_y);
                        try {
                            preStatement = conn.prepareStatement("INSERT INTO collectTable VALUES (?,?)");
                            preStatement.setString(1, spref.getString("userID",""));
                            preStatement.setInt(2, (int)IB.getTag(R.id.A_id));
                            ResultSet result = preStatement.executeQuery();
                            adapter.refreshArticles(new getArticles().getAllArticles("Select * from article where article_mid='"+spref.getString("userID","")+"'",spref.getString("userID","")));
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }else{
                    Intent intent = new Intent(getActivity(),EditArticle.class);
                    intent.putExtra("A_id",view.getTag(R.id.item_A_id)+"");
                    intent.putExtra("A_title",view.getTag(R.id.item_A_title)+"");
                    intent.putExtra("A_author",view.getTag(R.id.item_A_author)+"");
                    intent.putExtra("A_Star",view.getTag(R.id.item_A_star_num)+"");
                    intent.putExtra("A_date",view.getTag(R.id.item_A_createDate)+"");
                    intent.putExtra("A_content",view.getTag(R.id.item_A_content)+"");
                    intent.putExtra("A_type",view.getTag(R.id.item_A_typeA)+"");

                    startActivity(intent);
                }

            }
        });

        setHasOptionsMenu(true);
        return view;

    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menu_close, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.returnArticleList :
                android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.screen_area,new CommunicateFragment()).addToBackStack(null);
                ft.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
