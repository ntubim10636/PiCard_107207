package com.example.ntub.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ntub.myapplication.LoginActivity.KEY;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    SharedPreferences spref;
    MSSQLconnection connectionDB=new MSSQLconnection();
    Connection conn= connectionDB.CONN();
    PreparedStatement stmt;
    ResultSet rs1;

    String sname;
    String stel;
    String scell;
    String semail;
    String scomname;
    String saddr;

    private TextView name,tel,cell,email,comname,addr;



    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((MainActivity)getActivity()).setActionBarTitle("個人名片");
        ((MainActivity)getActivity()).getSupportActionBar().setSubtitle("");

        spref = getActivity().getApplication().getSharedPreferences(KEY,MODE_PRIVATE);
        setHasOptionsMenu(true);

        View v = inflater.inflate(R.layout.fragment_home, container, false);

        name=v.findViewById(R.id.name);
        tel=v.findViewById(R.id.tel);
        cell=v.findViewById(R.id.cell);
        email=v.findViewById(R.id.email);
        comname=v.findViewById(R.id.comname);
        addr=v.findViewById(R.id.addr);





        String query = "Select * from card where card_id ='"+spref.getString("userID","")+"'";

        try {
            stmt = conn.prepareStatement(query);
            rs1 = stmt.executeQuery();
            rs1.next();

            sname=rs1.getString("card_name").trim();
            stel=rs1.getString("card_tel").trim();
            scell=rs1.getString("card_cel").trim();
            semail=rs1.getString("card_email").trim();
            scomname=rs1.getString("card_company").trim();
            saddr=rs1.getString("card_addr").trim();


        } catch (SQLException e) {
            e.printStackTrace();
        }
        name.setText(sname);
        tel.setText(stel);

        cell.setText(scell);
        email.setText(semail);
        comname.setText(scomname);

        addr.setText(saddr);








        // Inflate the layout for this fragment
        return v;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.home_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout :
                spref.edit().clear().commit();

                Intent intent = new Intent();
                intent.setClass((MainActivity)getActivity(),LoginActivity.class);
                startActivity(intent);
                Toast.makeText((MainActivity)getActivity(),"已登出", Toast.LENGTH_LONG).show();
                return true;
            case R.id.editArticle :
                android.support.v4.app.FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.screen_area,new editmycard()).addToBackStack(null);
                ft.commit();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
