package com.example.ntub.myapplication;

import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.Date;


public class Article{
    private int id;
    private String title;
    private String author;
    private String  content;
    private String createDate;
    private int typeA;
    private int star_num;
    private boolean isCollect;

    public Article(int id, String title, String author, String content, String createDate,int typeA, int star_num, boolean isCollect){
        this.id=id;
        this.title =title;
        this.author =author;
        this.content =content;
        this.createDate =createDate;
        this.typeA =typeA;
        this.star_num =star_num;
        this.isCollect =isCollect;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createData) {
        this.createDate = createData;
    }

    public int getTypeA() {
        return typeA;
    }

    public void setTypeA(int typeA) {
        this.typeA = typeA;
    }

    public boolean isCollect() {
        return isCollect;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getStar_num() {
        return star_num;
    }

    public void setStar_num(int star_num) {
        this.star_num = star_num;
    }

    public boolean getisCollect() {
        return isCollect;
    }

    public void setCollect(boolean collect) {
        isCollect = collect;
    }

}
